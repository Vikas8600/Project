from django.shortcuts import render
from .models import Employee

def showIndex(request):
    return render(request,"index.html")


def registerEmployee(request):
    return render(request,"register.html")


def saveEmployee(request):
    id = request.POST.get("idno")
    na = request.POST.get("name")
    sal = request.POST.get("sal")

    # Creating Object and Passing Param's
    e1 = Employee(idno=id,name=na,salary=sal)
    # save means Commit
    e1.save()
    return render(request,"register.html",{"message":"Saved"})


def viewAllEmployees(request):
    qs = Employee.objects.all()
    return render(request,"viewall.html",{"data":qs})


def deleteEmployee(request):
    id = request.GET.get("idno")
    Employee.objects.filter(idno=id).delete()
    qs = Employee.objects.all()
    return render(request, "viewall.html", {"data": qs})


def showUpdateEmployee(request):
    id = request.POST.get("id")

    #result = Employee.objects.filter(idno=id) # Will return QuerySet

    result = Employee.objects.get(idno=id)

    return render(request,"update.html",{"data":result})

def updateEmployee(request):
    id = request.POST.get("idno")
    na = request.POST.get("name")
    sal = request.POST.get("sal")

    e1 = Employee(idno=id,name=na,salary=sal)
    e1.save()
    qs = Employee.objects.all()
    return render(request, "viewall.html", {"data": qs})

