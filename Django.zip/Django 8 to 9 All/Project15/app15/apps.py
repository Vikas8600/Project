from django.apps import AppConfig


class App15Config(AppConfig):
    name = 'app15'
