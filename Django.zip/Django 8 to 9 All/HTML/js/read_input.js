

function readName()
{
    var name = document.getElementById("t1").value

    document.getElementById("s1").innerText=name
}

// function password_check()
// {
//     var password = document.getElementById("p1").value
//     var len = password.length
//     var mess = ""
//     if (len < 8)
//     {
//         mess = "Poor"
//     }
//     else
//         {
//             if (len == 8)
//             {
//                 mess = "Good"
//             }
//         else {
//             mess = "Strong"
//         }
//     }
//     document.getElementById("s1").innerText = mess
// }

function password_check()
{
    var l = document.getElementById("p1").value.length
    if (l < 8)
    {
        document.getElementById("s1").innerText = "Poor"
        document.getElementById("s2").innerText = ""
        document.getElementById("s3").innerText = ""
    }
    else {
        if (l == 8)
        {
            document.getElementById("s2").innerText = "Good"
            document.getElementById("s1").innerText = ""
            document.getElementById("s3").innerText = ""
        }
        else
        {
            document.getElementById("s3").innerText = "Strong"
            document.getElementById("s2").innerText = ""
            document.getElementById("s1").innerText = ""
        }
    }
}

// function checkForm()
// {
//    var name = document.getElementById("t2").value
//
//     for (var x = 0;x<name.length;x++){
//         if (name.charCodeAt(x) >= 97 && name.charCodeAt(x) <= 122 ){
//             continue
//         }
//         else{
//         if (name.charCodeAt(x) >= 65 && name.charCodeAt(x) <= 90 ){
//             continue
//         }else{
//                 break
//             }
//         }
//    }
//     if(x == name.length){
//         return true
//     }
//     else {
//         document.getElementById("s1").innerText = "Invalid"
//         return false
//     }
// }


function checkForm()
{
    var name = document.getElementById("t2").value
    var regex = /^[A-Za-z]+$/

    if (regex.test(name))
    {
        return true
    }
    else {
        document.getElementById("s1").innerText = "Invalid"
        return false
    }
}








