
function show()
{
    alert("Hi I am .js File")
}

function display()
{
    alert("Please Don't Touch Me")
}


function readname()
{
    var name = document.getElementById("t1").value
    document.write(name)
}










