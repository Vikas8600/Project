
import random
print(random.randint(100000,999999))