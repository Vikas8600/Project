from django.db import models

class Employee(models.Model):
    pass

