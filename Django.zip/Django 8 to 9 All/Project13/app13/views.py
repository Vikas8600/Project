from django.shortcuts import render
from Project13 import settings as se
from django.core.mail import send_mail

def showIndex(request):
    return render(request,"index.html")

def validate(request):
    uname = request.POST.get("t1")
    upass = request.POST.get("t2")
    if uname == "sathya" and upass == "tech":
        import random
        otp = random.randint(100000, 999999)

        subject = " One Time Password "
        message = '''
        Hello User This is A Mail From Naveen Kumar
        Please Find Your One Time Password'''+str(otp)

        send_mail(subject,message,se.EMAIL_HOST_USER,["naveenandroid6557@gmail.com"])

        return render(request,"welcome.html",{"message":"Welcome Sathya"})
    else:
        return render(request,"index.html",{"message":"Invalid User"})

