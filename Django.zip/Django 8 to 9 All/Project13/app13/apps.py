from django.apps import AppConfig


class App13Config(AppConfig):
    name = 'app13'
