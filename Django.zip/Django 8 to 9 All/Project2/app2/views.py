from django.http import HttpResponse

def wishHtml(req):
    mess = "<html><body bgcolor = 'yellow'><h1>Hello Django</h1></body></html>"
    return HttpResponse(mess)
    
