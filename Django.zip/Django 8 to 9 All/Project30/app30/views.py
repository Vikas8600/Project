from django.shortcuts import render,redirect
from .forms import CourseForm,StudentForm
from .models import Course,Student

def showIndex(request):
        return render(request,"index.html")

def addCourse(request):
    cf = CourseForm()
    return render(request,"addc.html",{"form":cf})


def saveCourse(request):
    name = request.POST.get("name")
    fees = request.POST.get("fees")
    Course(name=name,fees=fees).save()
    return redirect('main')


def addStudent(request):
    sf = StudentForm()
    return render(request, "adds.html", {"form": sf})


def saveStudent(request):
    name = request.POST.get("name")
    subj = request.POST.getlist("subject")

    stu = Student.objects.create(name=name)
    stu.subject.set(subj)

    return redirect("/")


def viewAllCourse(request):
    return render(request,"viewallC.html",{"data":Course.objects.all()})


def viewAllStudents(request):
    return render(request,"viewallS.html",{"data":Student.objects.all()})