from django.apps import AppConfig


class App30Config(AppConfig):
    name = 'app30'
