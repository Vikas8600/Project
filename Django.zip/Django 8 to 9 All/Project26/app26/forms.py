
from django import forms
from .models import EmployeeModel

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = EmployeeModel
        # fields = "__all__" # using all fields
        fields = ['idno','salary','name']

        labels = {
            'idno':'EMPLOYEE IDNO',
            'name':'EMPLOYEE NAME',
            'salary':'EMPLOYEE SALARY'
        }

        widgets = {
            'salary':forms.PasswordInput
        }

