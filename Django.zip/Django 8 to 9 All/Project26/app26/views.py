from django.shortcuts import render
from .forms import EmployeeForm
from .models import EmployeeModel

def showIndex(request):
    ef = EmployeeForm()
    return render(request,"index.html",{"form":ef})


def saveEmployee(request):
    id = request.POST.get("idno")
    name = request.POST.get("name")
    salary = request.POST.get("salary")
    EmployeeModel(idno=id,name=name,salary=salary).save()
    ef = EmployeeForm()
    return render(request,"index.html",{"message":"saved","form":ef})