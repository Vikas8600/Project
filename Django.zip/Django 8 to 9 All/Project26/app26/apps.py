from django.apps import AppConfig


class App26Config(AppConfig):
    name = 'app26'
