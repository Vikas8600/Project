from django.shortcuts import render

def showIndex(request):
    return render(request,"index.html")


def showData(request):
    name = request.POST.get("t1")
    age = request.POST.get("t2")
    cno = request.POST.get("t3")
    email = request.POST.get("t4")

    #d1 = {"name":name,"age":age,"contact":cno,"emailid":email}

    # l1 = [("name",name),("age",age),("contact",cno),("emailid",email)]
    # d1 = dict(l1)
    # print(d1)
    # print(type(d1))

    d1 = makedict(name=name,age=age,contact=cno,emailid=email)

    return render(request,"details.html",d1)


def makedict(**kwargs):
    return kwargs


