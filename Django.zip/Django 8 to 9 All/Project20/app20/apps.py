from django.apps import AppConfig


class App20Config(AppConfig):
    name = 'app20'
