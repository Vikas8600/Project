from django.apps import AppConfig


class App28Config(AppConfig):
    name = 'app28'
