from django.views.generic import CreateView
from django.views.generic import ListView
from django.views.generic import DeleteView
from django.views.generic import UpdateView
from django.views.generic import DetailView
from django.views.generic import RedirectView

from django.contrib.messages.views import SuccessMessageMixin


from .models import EmployeeModel

class CreateNewEmployee(SuccessMessageMixin,CreateView):
    model = EmployeeModel
    template_name = "register.html"
    fields = ['idno','name','salary','image']
    success_url = '/index/'
    success_message = "Employee Saved"

class ViewAllEmployees(ListView):
    model = EmployeeModel
    template_name = "viewall.html"
    

class DeleteAEmployee(DeleteView):
    model = EmployeeModel
    success_url = '/all/'
    template_name = 'delete_conform.html'

class UpdateAEmployee(UpdateView):
    model = EmployeeModel
    success_url = '/all/'
    template_name = 'update.html'
    fields = ['name','salary','image']

class ViewOne(DetailView):
    model = EmployeeModel
    template_name = "viewone.html"

class Cancel(RedirectView):
    url = '/all/'

