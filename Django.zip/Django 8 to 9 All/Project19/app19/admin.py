from django.contrib import admin
from .models import HODModel,FacultyModel


admin.site.register(HODModel)
admin.site.register(FacultyModel)
