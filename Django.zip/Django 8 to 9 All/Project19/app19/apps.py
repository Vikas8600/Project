from django.apps import AppConfig


class App19Config(AppConfig):
    name = 'app19'
