from django.db import models

class HODModel(models.Model):
    no = models.IntegerField(auto_created=True)
    name = models.CharField(max_length=50)
    contactno = models.IntegerField()
    exp = models.IntegerField()
    brach = models.CharField(max_length=20)
    himage = models.ImageField(upload_to='hod/')

    def __str__(self):
        return self.name

class FacultyModel(models.Model):
    no = models.IntegerField(auto_created=True)
    name = models.CharField(max_length=50)
    contactno = models.IntegerField()
    exp = models.IntegerField()
    brach = models.CharField(max_length=20)
    fimage = models.ImageField(upload_to='faculty/')

    def __str__(self):
        return self.name


