from django.apps import AppConfig


class App6Config(AppConfig):
    name = 'app6'
