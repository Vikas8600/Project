from django.apps import AppConfig


class App25Config(AppConfig):
    name = 'app25'
