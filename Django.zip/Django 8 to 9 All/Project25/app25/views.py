from django.shortcuts import render
from django.shortcuts import redirect
from django.views.decorators.cache import cache_control

from .models import Login

@cache_control(no_cache=True, must_revalidate=True,no_store=True)
def showIndex(request):
    try:
        val = request.session["status"]
        return render(request, "welcome.html", {"message": val})
    except KeyError:
        return render(request,"index.html")


def loginCheck(request):
    username = request.POST["uname"]
    password = request.POST["upass"]
    try:
        Login.objects.get(email=username,password=password)
        request.session["status"] = username
        #request.session.set_expiry(30)
        return render(request,"welcome.html",{"message":username})
    except KeyError:
        return showIndex(request)


def logout(request):
    del request.session["status"]
    #return render(request,"index.html")
    return redirect('main')