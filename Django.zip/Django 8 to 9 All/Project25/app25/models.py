from django.db import models

class Login(models.Model):
    email = models.EmailField(max_length=100,primary_key=True)
    password = models.CharField(max_length=30)


