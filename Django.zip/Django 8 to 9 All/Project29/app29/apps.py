from django.apps import AppConfig


class App29Config(AppConfig):
    name = 'app29'
