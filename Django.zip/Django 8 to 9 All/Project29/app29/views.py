from django.core.paginator import Paginator
from django.shortcuts import render
from .models import Employee

def showIndex(request):
    page_no = request.GET.get("pageno")
    qs = Employee.objects.all()
    p = Paginator(qs,3)
    if page_no:
        pg = p.page(int(page_no))
    else:
        pg = p.page(1)
    return render(request,"index.html",{"data":pg})