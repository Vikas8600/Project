from django.shortcuts import render
from .models import Login

def userLogin(request):
    try:
        if request.COOKIES["status"]:
            return render(request, "welcome.html", {"message": "Welcome User"})
        else:
            return render(request,"index.html")
    except KeyError:
        return render(request, "index.html")


def loginCheck(request):
    uname = request.POST.get("uname")
    upass = request.POST.get("upass")
    try:
        Login.objects.get(username=uname,password=upass)
        response = render(request, "welcome.html", {"message": "Welcome User"})
        response.set_cookie("status",True)
        return response
    except Login.DoesNotExist:
        return render(request,"index.html",{"message":"Invalid User"})


def logoutuser(request):
    del request.COOKIES["status"]
    return userLogin(request)