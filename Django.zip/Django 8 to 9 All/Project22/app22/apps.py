from django.apps import AppConfig


class App22Config(AppConfig):
    name = 'app22'
