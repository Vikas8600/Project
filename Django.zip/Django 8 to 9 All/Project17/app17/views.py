from django.shortcuts import render
import datetime

def showIndex(request):
    da = datetime.date.today()
    data = {
        "nos":[1,2,3,4,5,6,7,8,9,89],
        "val1":4500,
        "val2":9052492329,
        "val3":da
    }
    return render(request,"index.html",data)