
import datetime as dt

s = dt.date
print(s.today())



