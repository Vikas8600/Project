from django.apps import AppConfig


class App17Config(AppConfig):
    name = 'app17'
