from django.shortcuts import render
from django.http import HttpResponse

def showIndex(request):
    return render(request,"index.html")

def showData(request):
    name = request.POST.get("t1")
    salary = request.POST.get("t2")
    print(name,salary)
    return HttpResponse("Ok")