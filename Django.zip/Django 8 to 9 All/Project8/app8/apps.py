from django.apps import AppConfig


class App8Config(AppConfig):
    name = 'app8'
