from django.apps import AppConfig


class App31Config(AppConfig):
    name = 'app31'
