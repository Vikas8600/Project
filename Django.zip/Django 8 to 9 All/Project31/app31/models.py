from django.db import models

class Facutlty(models.Model):
    fid = models.IntegerField(primary_key=True)
    fname = models.CharField(max_length=30)
    course = models.CharField(max_length=30)

    def __str__(self):
        return self.fname

class Student(models.Model):
    sid = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    faculty_id = models.ForeignKey(Facutlty,on_delete=models.CASCADE)

