from django.shortcuts import render,redirect
from .models import Facutlty,Student
from .forms import StudentForm,FacultyForm


def showIndex(request):
    return render(request,"index.html")


def addFaculty(request):
    return render(request,"addF.html",{"form":FacultyForm()})


def addStudent(request):
    return render(request, "addS.html",{"form":StudentForm()})


def viewStudent(request):
    return render(request,"viewS.html",{"data":Student.objects.all()})


def viewFaculty(request):
    return render(request, "viewF.html", {"data": Facutlty.objects.all()})


def saveFaculty(request):
    id = request.POST.get("fid")
    name = request.POST.get("fname")
    course = request.POST.get("course")
    Facutlty(fid=id,fname=name,course=course).save()
    return redirect('/')


def savetudent(request):
    name = request.POST.get("name")
    fid = request.POST.get("faculty_id")
    Student(name=name,faculty_id_id=fid).save()
    return redirect('/')