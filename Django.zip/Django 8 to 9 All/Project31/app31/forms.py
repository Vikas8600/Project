from django import forms
from .models import Student,Facutlty

class FacultyForm(forms.ModelForm):
    class Meta:
        model =Facutlty
        fields = "__all__"

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = "__all__"