from django.http import HttpResponse
from django.shortcuts import render
from .models import Product

def readAll(request):
    all_products = Product.objects.all()
    return render(request, "index.html", {"data": all_products})


def openMain(request):
    return readAll(request)


def saveProduct(request):
    p_no = request.POST.get("no")
    p_nmae = request.POST.get("name")
    p_price = request.POST.get("price")
    p_image = request.FILES["image"]

    p = Product(no=p_no,name=p_nmae,price=p_price,image=p_image)
    p.save()
    return readAll(request)


def deleteProduct(request):
    pno = request.GET.get("pno")
    Product.objects.filter(no=pno).delete()
    return readAll(request)

