from django.apps import AppConfig


class App18Config(AppConfig):
    name = 'app18'
