from django.apps import AppConfig


class App12Config(AppConfig):
    name = 'app12'
