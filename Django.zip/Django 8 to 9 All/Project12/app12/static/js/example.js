
function read()
{
    var name = document.getElementById("n1").value
    document.getElementById("s1").innerText = name
}