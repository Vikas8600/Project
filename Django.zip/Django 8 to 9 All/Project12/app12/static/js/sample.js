
function show_dialog()
{
    alert("Clicked on Button")
}