from django.apps import AppConfig


class App27Config(AppConfig):
    name = 'app27'
