from django.shortcuts import render
from django.views.generic import TemplateView
from django.views.generic import CreateView
from .models import EmployeeModel


class Main(TemplateView):
    template_name = "index.html"

class NewEmployee(TemplateView):
    template_name = "add_new.html"


class SaveEmployee(CreateView):
    model = EmployeeModel
    template_name = "index.html"
    fields = ['idno','name','salary']





