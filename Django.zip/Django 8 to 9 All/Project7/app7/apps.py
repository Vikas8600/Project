from django.apps import AppConfig


class App7Config(AppConfig):
    name = 'app7'
