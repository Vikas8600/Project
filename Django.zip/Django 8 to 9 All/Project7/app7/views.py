from django.shortcuts import render

def showIndex(request):
    d1 = {
        "101":{"name":"Ravi","exp":1.2,"salary":185000.00},
        "102":{"name":"kumar","exp":8,"salary":225000.00},
        "103":{"name":"Rama","exp":2.5,"salary":85000.00},
        "104":{"name":"Raja","exp":0,"salary":25000.00},
        "105":{"name":"Rani","exp":2.6,"salary":26000.00}
          }
    return render(request,"index.html",{"data":d1})