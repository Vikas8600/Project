from django.http import HttpResponse
from django.shortcuts import render,redirect

def showIndex(request):
    return render(request,"index.html")


def openNext(request):
    return redirect('next',id=101,name="ravi",salary="185000.00")


def nextPage(request,id,name,salary):
    return HttpResponse(str(id)+"--"+name+"--"+salary)