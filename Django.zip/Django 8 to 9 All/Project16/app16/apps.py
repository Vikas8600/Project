from django.apps import AppConfig


class App16Config(AppConfig):
    name = 'app16'
