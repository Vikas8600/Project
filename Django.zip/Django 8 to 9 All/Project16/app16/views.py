from django.shortcuts import render

def showIndex(request):
    data = {"no":100,"val1":"Naveen's","val2":"sathya","val3":"This is a string without space"}
    return render(request,"index.html",data)