from django.apps import AppConfig


class App32Config(AppConfig):
    name = 'app32'
