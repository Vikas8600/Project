from django.shortcuts import render,redirect
from .forms import PlaceForm,RestaurantForm
from .models import Restaurant,Place

def showIndex(request):
    return render(request,"index.html")


def addPlace(request):
    return render(request,"addp.html",{"form":PlaceForm()})


def addRest(request):
    return render(request, "addr.html", {"form": RestaurantForm()})


def viewRest(request):
    return render(request,"viewR.html",{"data":Restaurant.objects.all()})


def savePlace(request):
    name = request.POST.get("name")
    address = request.POST.get("address")
    Place(name=name,address=address).save()
    return redirect('/')


def saveRest(request):
    place = request.POST.get("place")
    serves_pizza = request.POST.get("rest_name")
    Restaurant(place_id=place,rest_name=serves_pizza).save()
    return redirect('/')