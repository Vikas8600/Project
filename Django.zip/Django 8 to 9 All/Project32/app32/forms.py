from django import forms
from .models import Place,Restaurant

class PlaceForm(forms.ModelForm):
    class Meta:
        model = Place
        fields = "__all__"

class RestaurantForm(forms.ModelForm):
    class Meta:
        model = Restaurant
        fields = "__all__"