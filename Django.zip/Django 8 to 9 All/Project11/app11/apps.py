from django.apps import AppConfig


class App11Config(AppConfig):
    name = 'app11'
