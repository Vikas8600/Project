from django.apps import AppConfig


class App14Config(AppConfig):
    name = 'app14'
