from django.http import HttpResponse
from django.shortcuts import render

def showIndex(request):
    return render(request,"index.html")


def getExample(request):
    upass = request.GET.get("g1")
    return HttpResponse("I am Get :"+upass)


def postExample(request):
    upass = request.POST.get("p1")
    return HttpResponse("I am Post : "+upass)