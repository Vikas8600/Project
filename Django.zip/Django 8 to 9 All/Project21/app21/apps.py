from django.apps import AppConfig


class App21Config(AppConfig):
    name = 'app21'
