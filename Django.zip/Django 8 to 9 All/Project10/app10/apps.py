from django.apps import AppConfig


class App10Config(AppConfig):
    name = 'app10'
