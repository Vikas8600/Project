from django.apps import AppConfig


class App34Config(AppConfig):
    name = 'app34'
