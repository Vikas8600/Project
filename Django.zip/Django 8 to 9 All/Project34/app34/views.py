from django.shortcuts import redirect
from django.views.generic import View

# def checkMethod(request):
#     if request.method == "POST":
#         print("I am Post")
#     else:
#         print("I am Get")
#     return None


class Check(View):
    def post(self,request):
        print("I am Post.....")
        return redirect("http://www.facebook.com")
    def get(self,request):
        print("I am Get....")
        return redirect("http://www.google.com")