from django.shortcuts import render

def showIndex(request):
    return render(request,"index.html")

total = 0
def countBag(request):
    global total
    price = 2500
    total = total+price
    return render(request,"index.html",{"total":total})

def countLaptop(request):
    global total
    price = 45000
    total = total + price
    return render(request, "index.html", {"total": total})

def countMobile(request):
    global total
    price = 12500
    total = total + price
    return render(request, "index.html", {"total": total})
