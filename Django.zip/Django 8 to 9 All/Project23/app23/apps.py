from django.apps import AppConfig


class App23Config(AppConfig):
    name = 'app23'
