from django.contrib.sessions.backends.base import SessionBase
from django.shortcuts import render

def showMain(request):
    return render(request,"index.html")


def postComment(request):
    contact = request.POST["cno"]
    message = request.POST["comment"]
    try:
        valu = request.session["status"]
        if valu == contact:
            return render(request, "index.html", {"message": "Comment is Given With this no"})
        else:
            request.session["status"] = contact
            request.session.set_expiry(30)
            return render(request,"index.html",{"message":"Comment is Saved"})
    except KeyError:
        request.session["status"] = contact
        request.session.set_expiry(30)
        return render(request, "index.html", {"message": "Comment is Saved"})